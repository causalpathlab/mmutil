#include <algorithm>
#include <functional>
#include <unordered_map>
#include <tuple>

// #include <execution> c++17

#ifndef STD_UTIL_HH_
#define STD_UTIL_HH_

template <typename Vec>
auto
std_argsort(const Vec &data)
{
    using Index = std::ptrdiff_t;
    std::vector<Index> index(data.size());
    std::iota(std::begin(index), std::end(index), 0);
    std::sort(std::begin(index), std::end(index), [&](Index lhs, Index rhs) {
        return data.at(lhs) > data.at(rhs);
    });
    return index;
}

/**
 * vector -> map: name -> position index
 */
template <typename S, typename IDX>
std::unordered_map<S, IDX>
make_position_dict(const std::vector<S> &name_vec)
{

    std::unordered_map<S, IDX> name_to_id;

    for (IDX i = 0; i < name_vec.size(); ++i) {
        const S &j = name_vec.at(i);
        name_to_id[j] = i;
    }

    return name_to_id;
}

template <typename S, typename IDX>
std::tuple<std::vector<IDX>, std::vector<S>, std::unordered_map<S, IDX>>
make_indexed_vector(const std::vector<S> &name_vec)
{

    std::unordered_map<S, IDX> name_to_id;
    std::vector<S> id_to_name;
    std::vector<IDX> id_vec;
    id_vec.reserve(name_vec.size());

    for (IDX i = 0; i < name_vec.size(); ++i) {
        const S &ii = name_vec.at(i);
        if (name_to_id.count(ii) == 0) {
            const IDX j = name_to_id.size();
            name_to_id[ii] = j;
            id_to_name.push_back(ii);
        }
        id_vec.emplace_back(name_to_id.at(ii));
    }

    return std::make_tuple(id_vec, id_to_name, name_to_id);
}

template <typename IDX>
std::vector<std::vector<IDX>>
make_index_vec_vec(const std::vector<IDX> &_id)
{
    using vec_ivec = std::vector<std::vector<IDX>>;

    const IDX nn = *std::max_element(_id.begin(), _id.end()) + 1;

    vec_ivec ret(nn, std::vector<IDX>{});

    for (IDX i = 0; i < _id.size(); ++i) {
        const IDX k = _id.at(i);
        ret[k].push_back(i);
    }
    return ret;
}

// template <typename Vec>
// auto
// std_argsort_par(const Vec& data) {
//   using Index = std::ptrdiff_t;
//   std::vector<Index> index(data.size());
//   std::iota(std::begin(index), std::end(index), 0);
//   std::sort(std::execution::par, std::begin(index), std::end(index),
//             [&](Index lhs, Index rhs) { return data.at(lhs) > data.at(rhs);
//             });
//   return index;
// }

#endif
